/** Automatically generated file. DO NOT MODIFY */
package com.mnightt.numberful.cn;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
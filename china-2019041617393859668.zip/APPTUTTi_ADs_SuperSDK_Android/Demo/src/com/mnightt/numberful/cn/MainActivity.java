package com.mnightt.numberful.cn;

import com.apptutti.ad.ADManager;
import com.apptutti.ad.SuperADPayListener;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {
	private Button btn_init;
	private Button btn_video;
	private Button btn_instl;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btn_init = (Button) findViewById(R.id.btn_init);
		btn_video = (Button) findViewById(R.id.btn_video);
		btn_instl = (Button) findViewById(R.id.btn_instl);

		btn_init.setOnClickListener(this);
		btn_video.setOnClickListener(this);
		btn_instl.setOnClickListener(this);
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.btn_init:
			ADManager.getInstance().init(this, new SuperADPayListener() {
				
				@Override
				public void VideoAdsLoadSuccess() {
					// TODO Auto-generated method stub
					Log.d("ADManager", "VideoAdsLoadSuccess");
				}
				
				@Override
				public void VideoAdsCallBack() {
					// TODO Auto-generated method stub
					Log.d("ADManager", "VideoAdsCallBack");
				}
			});
			break;
		case R.id.btn_video:
			ADManager.getInstance().videoAds(MainActivity.this);
			break;
		case R.id.btn_instl:
			ADManager.getInstance().interstitialAds(MainActivity.this);
			break;
		}
	}

}
